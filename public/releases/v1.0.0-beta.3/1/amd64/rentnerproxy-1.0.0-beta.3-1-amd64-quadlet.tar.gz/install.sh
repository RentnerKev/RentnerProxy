#!/bin/bash
set -eu
[[ $(id -u) == 0 ]] || exit 1
if command -v dpkg-query >/dev/null && dpkg-query --search /usr/bin/rentnerproxy >/dev/null 2>&1; then echo "Use apt-get to manage rentnerproxy." >&2; exit 1; fi
if command -v rpm >/dev/null && rpm -qf /usr/bin/rentnerproxy >/dev/null 2>&1; then echo "Use dnf to manage rentnerproxy." >&2; exit 1; fi
here=$(cd -- "$(dirname -- "$0")" && pwd)
set -eu
umask 077
if [[ -f /usr/share/rentnerproxy/image && ! -L /usr/share/rentnerproxy/image ]]; then
    if [[ -e /var/lib/rentnerproxy-distribution || -L /var/lib/rentnerproxy-distribution ]]; then
        [[ -d /var/lib/rentnerproxy-distribution && ! -L /var/lib/rentnerproxy-distribution && $(stat -c %u /var/lib/rentnerproxy-distribution) == 0 ]] || exit 1
    fi
    install -d -m 0700 /var/lib/rentnerproxy-distribution
    install -m 0600 /usr/share/rentnerproxy/image /var/lib/rentnerproxy-distribution/previous.image
    if [[ -f /usr/share/rentnerproxy/version ]]; then
        install -m 0600 /usr/share/rentnerproxy/version /var/lib/rentnerproxy-distribution/previous.version
    fi
fi
install -D -m 755 -- "$here/usr/bin/rentnerproxy" "/usr/bin/rentnerproxy"
install -D -m 644 -- "$here/usr/share/containers/systemd/rentnerproxy.container" "/usr/share/containers/systemd/rentnerproxy.container"
install -D -m 644 -- "$here/usr/share/containers/systemd/rentnerproxy.volume" "/usr/share/containers/systemd/rentnerproxy.volume"
install -D -m 644 -- "$here/usr/share/rentnerproxy/appliance.env.example" "/usr/share/rentnerproxy/appliance.env.example"
install -D -m 644 -- "$here/usr/share/rentnerproxy/release.json" "/usr/share/rentnerproxy/release.json"
install -D -m 644 -- "$here/usr/share/rentnerproxy/image" "/usr/share/rentnerproxy/image"
install -D -m 644 -- "$here/usr/share/rentnerproxy/platform" "/usr/share/rentnerproxy/platform"
install -D -m 644 -- "$here/usr/share/rentnerproxy/version" "/usr/share/rentnerproxy/version"
install -D -m 644 -- "$here/usr/share/licenses/rentnerproxy/LICENSE" "/usr/share/licenses/rentnerproxy/LICENSE"
set -eu
umask 077
if [[ -e /etc/rentnerproxy || -L /etc/rentnerproxy ]]; then
    [[ -d /etc/rentnerproxy && ! -L /etc/rentnerproxy && $(stat -c %u /etc/rentnerproxy) == 0 ]] || exit 1
else
    install -d -m 0700 /etc/rentnerproxy
fi
if [[ -d /run/systemd/system ]]; then
    systemctl daemon-reload
    if systemctl is-active --quiet rentnerproxy.service; then
        /usr/bin/rentnerproxy restart
    fi
fi
