#!/bin/bash
set -eu
[[ $(id -u) == 0 ]] || exit 1
if command -v dpkg-query >/dev/null && dpkg-query --search /usr/bin/rentnerproxy >/dev/null 2>&1; then echo "Use apt-get to manage rentnerproxy." >&2; exit 1; fi
if command -v rpm >/dev/null && rpm -qf /usr/bin/rentnerproxy >/dev/null 2>&1; then echo "Use dnf to manage rentnerproxy." >&2; exit 1; fi
if [[ -e /usr/bin/rentnerproxy || -L /usr/bin/rentnerproxy ]]; then
    [[ -f /usr/bin/rentnerproxy && ! -L /usr/bin/rentnerproxy ]] || exit 1
    printf '%s\n' 'f7b1944bc59e2a0af6749eb4a04f74da73909dbe8aa34fb4b7d5243e626183fd  /usr/bin/rentnerproxy' | sha256sum --check --status
fi
if [[ -e /usr/share/containers/systemd/rentnerproxy.container || -L /usr/share/containers/systemd/rentnerproxy.container ]]; then
    [[ -f /usr/share/containers/systemd/rentnerproxy.container && ! -L /usr/share/containers/systemd/rentnerproxy.container ]] || exit 1
    printf '%s\n' 'e80dedf978619fab73b40de9c9e6e7ee6d3b374218ce85938f5a06e3fda17ad8  /usr/share/containers/systemd/rentnerproxy.container' | sha256sum --check --status
fi
if [[ -e /usr/share/containers/systemd/rentnerproxy.volume || -L /usr/share/containers/systemd/rentnerproxy.volume ]]; then
    [[ -f /usr/share/containers/systemd/rentnerproxy.volume && ! -L /usr/share/containers/systemd/rentnerproxy.volume ]] || exit 1
    printf '%s\n' '605cd2f64aec35ba56ce1f51f879c4f77d3133a9b6e906f4609662b7d7f9f3d1  /usr/share/containers/systemd/rentnerproxy.volume' | sha256sum --check --status
fi
if [[ -e /usr/share/rentnerproxy/appliance.env.example || -L /usr/share/rentnerproxy/appliance.env.example ]]; then
    [[ -f /usr/share/rentnerproxy/appliance.env.example && ! -L /usr/share/rentnerproxy/appliance.env.example ]] || exit 1
    printf '%s\n' '82acd9738d354f136f20700e216d0995699291bb93f20ed539d29c2d8588eb71  /usr/share/rentnerproxy/appliance.env.example' | sha256sum --check --status
fi
if [[ -e /usr/share/rentnerproxy/release.json || -L /usr/share/rentnerproxy/release.json ]]; then
    [[ -f /usr/share/rentnerproxy/release.json && ! -L /usr/share/rentnerproxy/release.json ]] || exit 1
    printf '%s\n' '8da4c7a6c68db3e9b240b6f27eb66daed91ac7956eba55f404c0ca32db14fd43  /usr/share/rentnerproxy/release.json' | sha256sum --check --status
fi
if [[ -e /usr/share/rentnerproxy/image || -L /usr/share/rentnerproxy/image ]]; then
    [[ -f /usr/share/rentnerproxy/image && ! -L /usr/share/rentnerproxy/image ]] || exit 1
    printf '%s\n' '07e0842d2fbce7c6e263782122782f1f7e7f2ec5907da886ef8a13eda4caaace  /usr/share/rentnerproxy/image' | sha256sum --check --status
fi
if [[ -e /usr/share/rentnerproxy/platform || -L /usr/share/rentnerproxy/platform ]]; then
    [[ -f /usr/share/rentnerproxy/platform && ! -L /usr/share/rentnerproxy/platform ]] || exit 1
    printf '%s\n' '8e0770e07c23940b641360866fee9a4fe9202fadae5086d5162337bab0307e89  /usr/share/rentnerproxy/platform' | sha256sum --check --status
fi
if [[ -e /usr/share/rentnerproxy/version || -L /usr/share/rentnerproxy/version ]]; then
    [[ -f /usr/share/rentnerproxy/version && ! -L /usr/share/rentnerproxy/version ]] || exit 1
    printf '%s\n' 'd04a4962bbc5a9a59c3641e66bb4e4e647fe28b20875e157cc9aaeb3df17058b  /usr/share/rentnerproxy/version' | sha256sum --check --status
fi
if [[ -e /usr/share/licenses/rentnerproxy/LICENSE || -L /usr/share/licenses/rentnerproxy/LICENSE ]]; then
    [[ -f /usr/share/licenses/rentnerproxy/LICENSE && ! -L /usr/share/licenses/rentnerproxy/LICENSE ]] || exit 1
    printf '%s\n' 'ceae383c8f5fcd4293b53caccefbf82a67518a0aa552cbc466c3b1bc7913d21a  /usr/share/licenses/rentnerproxy/LICENSE' | sha256sum --check --status
fi
if [[ -d /run/systemd/system ]] && systemctl cat rentnerproxy.service >/dev/null 2>&1; then
    if [[ -x /usr/bin/rentnerproxy ]]; then /usr/bin/rentnerproxy stop
    elif systemctl is-active --quiet rentnerproxy.service; then echo "Restore the matching CLI before stopping the active appliance." >&2; exit 1
    fi
fi
rm -f -- /usr/bin/rentnerproxy
rm -f -- /usr/share/containers/systemd/rentnerproxy.container
rm -f -- /usr/share/containers/systemd/rentnerproxy.volume
rm -f -- /usr/share/rentnerproxy/appliance.env.example
rm -f -- /usr/share/rentnerproxy/release.json
rm -f -- /usr/share/rentnerproxy/image
rm -f -- /usr/share/rentnerproxy/platform
rm -f -- /usr/share/rentnerproxy/version
rm -f -- /usr/share/licenses/rentnerproxy/LICENSE
if [[ -d /run/systemd/system ]]; then systemctl daemon-reload; fi
